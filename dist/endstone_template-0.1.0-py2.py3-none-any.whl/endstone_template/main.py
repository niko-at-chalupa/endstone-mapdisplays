from endstone import ColorFormat, boss
from endstone.event import event_handler, PlayerJoinEvent, PlayerChatEvent
from endstone.plugin import Plugin

class TemplatePlugin(Plugin):
    def on_enable(self) -> None:
        self.logger.info("on_enable is called!")
        self.register_events(self)

    @event_handler
    def on_player_join(self, event: PlayerJoinEvent):
        bar = boss.BossBar()
        bar.add_player(event.player)
        bar.title = "hello!!"